package com.example.bodyfitnessapp.ui.smsnotification;

import androidx.lifecycle.ViewModel;

public class SMSViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}