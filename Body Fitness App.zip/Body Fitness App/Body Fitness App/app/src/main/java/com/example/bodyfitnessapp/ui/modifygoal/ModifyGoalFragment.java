package com.example.bodyfitnessapp.ui.modifygoal;

import androidx.lifecycle.ViewModelProvider;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.bodyfitnessapp.R;
import com.example.bodyfitnessapp.SessionManager;

public class ModifyGoalFragment extends Fragment {

    private ModifyGoalViewModel mViewModel;
    private EditText editTextGoalWeight;
    private SessionManager sessionManager;

    public static ModifyGoalFragment newInstance() {
        return new ModifyGoalFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_modify_goal, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(ModifyGoalViewModel.class);
        // TODO: Use the ViewModel
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        editTextGoalWeight = view.findViewById(R.id.editTextGoalWeight);
        Button buttonUpdateGoal = view.findViewById(R.id.buttonUpdateGoal);
        sessionManager = new SessionManager(getContext());

        buttonUpdateGoal.setOnClickListener(v -> {
            String goalWeight = editTextGoalWeight.getText().toString();
            if (!goalWeight.isEmpty()) {
                sessionManager.setGoalWeight(goalWeight);
                Toast.makeText(getContext(), "Goal weight updated", Toast.LENGTH_SHORT).show();
                getActivity().onBackPressed();
            } else {
                Toast.makeText(getContext(), "Enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
