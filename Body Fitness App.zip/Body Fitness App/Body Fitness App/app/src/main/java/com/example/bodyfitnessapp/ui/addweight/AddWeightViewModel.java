package com.example.bodyfitnessapp.ui.addweight;

import androidx.lifecycle.ViewModel;

public class AddWeightViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
