package com.example.bodyfitnessapp.ui.signin;

import androidx.lifecycle.ViewModel;

public class SigninViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}