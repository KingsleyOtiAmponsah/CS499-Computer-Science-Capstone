package com.example.bodyfitnessapp.ui.signout;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigation;

import com.example.bodyfitnessapp.R;
import com.example.bodyfitnessapp.SessionManager;
import com.example.bodyfitnessapp.databinding.FragmentSignoutBinding;

public class SignoutFragment extends Fragment {

    private FragmentSignoutBinding binding;
    private SessionManager sessionManager;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SignoutViewModel signoutViewModel =
                new ViewModelProvider(this).get(SignoutViewModel.class);

        binding = FragmentSignoutBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        sessionManager = new SessionManager(getContext());

        Button buttonYes = binding.buttonYes;


        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.logoutUser();
                Toast.makeText(getActivity(), "User signed out successfully", Toast.LENGTH_SHORT).show();

                NavOptions navOptions = new NavOptions.Builder()
                        .setPopUpTo(R.id.nav_signout, true)
                        .build();
                Navigation.findNavController(v).navigate(R.id.action_nav_signout_to_nav_signin, null, navOptions);
            }
        });



        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
