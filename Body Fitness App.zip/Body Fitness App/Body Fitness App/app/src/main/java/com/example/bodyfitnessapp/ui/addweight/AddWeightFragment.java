package com.example.bodyfitnessapp.ui.addweight;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.bodyfitnessapp.DatabaseHelper;
import com.example.bodyfitnessapp.R;
import com.example.bodyfitnessapp.SessionManager;
import com.example.bodyfitnessapp.databinding.FragmentAddWeightBinding;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddWeightFragment extends Fragment {

    private FragmentAddWeightBinding binding;
    private DatabaseHelper dbHelper;
    private Calendar calendar;
    private SessionManager sessionManager; // Add this line

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        AddWeightViewModel addWeightViewModel = new ViewModelProvider(this).get(AddWeightViewModel.class);

        binding = FragmentAddWeightBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        dbHelper = new DatabaseHelper(getContext());
        calendar = Calendar.getInstance();
        sessionManager = new SessionManager(getContext()); // Initialize sessionManager

        EditText editTextWeight = binding.editTextWeight;
        Button buttonPickDate = binding.buttonPickDate;
        Button buttonPickTime = binding.buttonPickTime;
        TextView textViewPickedDate = binding.textViewPickedDate;
        TextView textViewPickedTime = binding.textViewPickedTime;
        Button buttonSaveWeight = binding.buttonSaveWeight;

        // Pre-populate current date and time
        updateLabel(textViewPickedDate, "yyyy-MM-dd");
        updateLabel(textViewPickedTime, "HH:mm");

        buttonPickDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        updateLabel(textViewPickedDate, "yyyy-MM-dd");
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        buttonPickTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);
                        updateLabel(textViewPickedTime, "HH:mm");
                    }
                }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
            }
        });

        buttonSaveWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String weight = editTextWeight.getText().toString();
                String date = textViewPickedDate.getText().toString().trim();
                String time = textViewPickedTime.getText().toString().trim();

                if (weight.isEmpty()) {
                    Toast.makeText(getContext(), "Please enter weight", Toast.LENGTH_SHORT).show();
                    return;
                }

                int userId = sessionManager.getUserId(); // Get the current user's ID
                dbHelper.addWeight(userId, weight, date, time);
                Toast.makeText(getContext(), "Weight added successfully", Toast.LENGTH_SHORT).show();
                Navigation.findNavController(view).navigateUp();  // Go back to the previous screen
            }
        });

        return root;
    }

    private void updateLabel(TextView textView, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.US);
        textView.setText(sdf.format(calendar.getTime()));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
