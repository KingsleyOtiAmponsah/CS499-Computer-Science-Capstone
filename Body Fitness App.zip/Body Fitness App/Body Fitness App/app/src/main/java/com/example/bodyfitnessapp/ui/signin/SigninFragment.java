package com.example.bodyfitnessapp.ui.signin;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import com.example.bodyfitnessapp.MainActivity;
import com.example.bodyfitnessapp.DatabaseHelper;
import com.example.bodyfitnessapp.R;
import com.example.bodyfitnessapp.SessionManager;
import com.example.bodyfitnessapp.databinding.FragmentSigninBinding;

public class SigninFragment extends Fragment {

    private FragmentSigninBinding binding;
    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSigninBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        dbHelper = new DatabaseHelper(getContext());
        sessionManager = new SessionManager(getContext());

        EditText editTextUsername = binding.editTextUsername;
        EditText editTextPassword = binding.editTextPassword;
        Button buttonSignin = binding.buttonLogin;
        Button buttonCreateAccount = binding.buttonCreateAccount;

        buttonSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getContext(), "Enter your username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                SQLiteDatabase db = dbHelper.getReadableDatabase();
                Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, null, DatabaseHelper.COLUMN_USERNAME + "=?", new String[]{username}, null, null, null);

                if (cursor != null && cursor.moveToFirst()) {
                    String storedPassword = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PASSWORD));
                    int userId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USER_ID)); // Get user ID

                    if (password.equals(storedPassword)) {
                        sessionManager.createLoginSession(username, userId); // Pass user ID
                        Toast.makeText(getContext(), "Login successful", Toast.LENGTH_SHORT).show();
                        MainActivity mainActivity = (MainActivity) getActivity();
                        if (mainActivity != null) {
                            mainActivity.updateNavigationHeaderUsername();
                        }
                        Navigation.findNavController(v).navigate(R.id.action_nav_signin_to_nav_home);

                    } else {
                        Toast.makeText(getContext(), "Wrong password", Toast.LENGTH_SHORT).show();
                    }
                    cursor.close();
                } else {
                    Toast.makeText(getContext(), "No user found", Toast.LENGTH_SHORT).show();
                }
                db.close();
            }
        });

        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getContext(), "Enter your username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                SQLiteDatabase db = dbHelper.getWritableDatabase();
                Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, null, DatabaseHelper.COLUMN_USERNAME + "=?", new String[]{username}, null, null, null);

                if (cursor != null && cursor.moveToFirst()) {
                    Toast.makeText(getContext(), "Username already exists", Toast.LENGTH_SHORT).show();
                    cursor.close();
                } else {
                    dbHelper.addUser(username, password);
                    Toast.makeText(getContext(), "Account created successfully, proceed to login", Toast.LENGTH_SHORT).show();
                }
                db.close();
            }
        });

        

        return root;
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
