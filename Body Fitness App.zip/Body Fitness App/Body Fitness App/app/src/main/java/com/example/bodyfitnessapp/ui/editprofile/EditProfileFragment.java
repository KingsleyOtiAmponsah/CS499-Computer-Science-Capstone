package com.example.bodyfitnessapp.ui.editprofile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.bodyfitnessapp.DatabaseHelper;
import com.example.bodyfitnessapp.MainActivity;
import com.example.bodyfitnessapp.R;
import com.example.bodyfitnessapp.SessionManager;
import com.example.bodyfitnessapp.databinding.FragmentEditprofileBinding;

public class EditProfileFragment extends Fragment {

    private FragmentEditprofileBinding binding;
    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        EditProfileViewModel editProfileViewModel =
                new ViewModelProvider(this).get(EditProfileViewModel.class);

        binding = FragmentEditprofileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        dbHelper = new DatabaseHelper(getContext());
        sessionManager = new SessionManager(getContext());

        EditText editTextNewUsername = binding.editTextNewUsername;
        EditText editTextNewPassword = binding.editTextNewPassword;
        Button buttonSaveChanges = binding.buttonSaveChanges;

        buttonSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newUsername = editTextNewUsername.getText().toString();
                String newPassword = editTextNewPassword.getText().toString();

                if (newUsername.isEmpty() && newPassword.isEmpty()) {
                    Toast.makeText(getContext(), "Enter a new username or password", Toast.LENGTH_SHORT).show();
                    return;
                }

                int userId = sessionManager.getUserId();

                if (!newUsername.isEmpty()) {
                    dbHelper.updateUsername(userId, newUsername);
                }

                if (!newPassword.isEmpty()) {
                    dbHelper.updatePassword(userId, newPassword);
                }
                MainActivity mainActivity = (MainActivity) getActivity();
                if (mainActivity != null) {
                    mainActivity.updateNavigationHeaderUsername();
                }
                Toast.makeText(getContext(), "You have successfully updated your profile", Toast.LENGTH_SHORT).show();

            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
