package com.example.bodyfitnessapp;

import android.app.Activity;

public class SMSPermissionActivity extends Activity {
}
