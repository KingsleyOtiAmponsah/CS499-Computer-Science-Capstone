package com.example.bodyfitnessapp.ui.modifygoal;

import androidx.lifecycle.ViewModel;

public class ModifyGoalViewModel extends ViewModel {
    // Add any required data and methods here
}
